document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    const colorPicker = document.getElementById('color-picker');
    const lineWidth = document.getElementById('line-width');
    const eraserBtn = document.getElementById('eraser');
    const clearBtn = document.getElementById('clear');
    const exportBtn = document.getElementById('export-btn');
    const resultContainer = document.getElementById('result-container');
    const imgurLink = document.getElementById('imgur-link');
    const loadingDiv = document.querySelector('.loading');

    // Initialize canvas with white background
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Drawing state
    let isDrawing = false;
    let lastX = 0;
    let lastY = 0;
    let currentColor = colorPicker.value;
    let isErasing = false;

    // Drawing functions
    function draw(e) {
        if (!isDrawing) return;
        const x = e.offsetX;
        const y = e.offsetY;

        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(x, y);
        ctx.stroke();

        [lastX, lastY] = [x, y];
    }

    // Event listeners for drawing
    canvas.addEventListener('mousedown', (e) => {
        isDrawing = true;
        [lastX, lastY] = [e.offsetX, e.offsetY];
        ctx.strokeStyle = isErasing ? 'white' : currentColor;
        ctx.lineWidth = lineWidth.value;
    });

    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', () => isDrawing = false);
    canvas.addEventListener('mouseout', () => isDrawing = false);

    // Color picker
    colorPicker.addEventListener('change', (e) => {
        currentColor = e.target.value;
        isErasing = false;
        eraserBtn.style.background = '#4CAF50';
    });

    // Line width
    lineWidth.addEventListener('input', (e) => {
        ctx.lineWidth = e.target.value;
    });

    // Eraser
    eraserBtn.addEventListener('click', () => {
        isErasing = !isErasing;
        eraserBtn.style.background = isErasing ? '#ff4444' : '#4CAF50';
    });

    // Clear canvas
    clearBtn.addEventListener('click', () => {
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
    });

    // Export to Imgur
    exportBtn.addEventListener('click', async () => {
        // Show loading state
        loadingDiv.classList.add('show');
        resultContainer.classList.remove('show');
        
        try {
            // Convert canvas to base64
            const imageData = canvas.toDataURL('image/png').split(',')[1];

            // Upload to Imgur
            const response = await fetch('https://api.imgur.com/3/image', {
                method: 'POST',
                headers: {
                    'Authorization': 'Client-ID 1e1a043695b8b75',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    image: imageData,
                    type: 'base64'
                })
            });

            const result = await response.json();

            if (result.success) {
                // Show success message with link
                imgurLink.href = result.data.link;
                imgurLink.textContent = result.data.link;
                resultContainer.classList.add('show');
            } else {
                throw new Error('Upload failed');
            }
        } catch (error) {
            alert('Failed to upload image. Please try again.');
            console.error('Upload error:', error);
        } finally {
            loadingDiv.classList.remove('show');
        }
    });
}); 